### Libraries to be used in this code
import pandas as pd
import numpy as np
import datetime
from dateutil import relativedelta,rrule
from datetime import datetime
import numpy_financial as npf






# Importing data from excel file


# This sheet is imorted for analysis  and insight purpose
IIR_Calculation = pd.read_excel(r"C://Users//ashwa//Downloads//Kroll_assignment//Loan_IRR_Calc_Model.xlsx",sheet_name=0).fillna(0)
IIR_Calculation.rename(columns={'Playdate':'Paydate'},inplace=True)


# These, below two data frame and the formulae will be used for  calculation  
Charged_off = pd.read_excel(r"C://Users//ashwa//Downloads//Kroll_assignment//Loan_IRR_Calc_Model.xlsx",sheet_name=1,index_col=0).fillna(0)
Prepay = pd.read_excel(r"C://Users//ashwa//Downloads//Kroll_assignment//Loan_IRR_Calc_Model.xlsx",sheet_name=2,index_col=0).fillna(0).iloc[:,:9]



# By looking analytically this can be extracted or it is already involed in pandas frame
Valuation_Date = '12/31/2017'
Grade = 'C4'
Issue_Date	= '8/24/2015'
Term	 = 36.00 
CouponRate	= 0.28 #28%
Invested	= 7500.00 
Outstanding_Balance	= 3228.61 
Recovery_Rate	= 0.08
Purchase_Premium	= 0.0514 # 5.14%
Servicing_Fee	= 0.0250 #2.50%
Earnout_Fee	= 0.0250 # 2.50%  
	
Default_Multiplier = 	1.000
Prepay_Multiplier = 1.000
Product_Pos	= 66





Months_n = [i for i in range(0,IIR_Calculation.shape[0])] #np.arange(1,IIR_Calculation.shape[0]+1)


## Calculating Payment count
Paymnt_Count_n = [i for i in range(0,IIR_Calculation.shape[0])] #np.arange(0,IIR_Calculation.shape[0]+1)


## Calculating PayDate
start_date = datetime.strptime(Issue_Date, "%m/%d/%Y")
start_date = datetime(start_date.year,start_date.month+1, start_date.day)

# Time iterator
it = iter([i.strftime('%d-%m-%Y') for i in rrule.rrule(rrule.MONTHLY, dtstart=start_date, until=None)])
Paydate_n = [next(it) for i in range(0,IIR_Calculation.shape[0])]



## Calculate Scheduled_Principal
Scheduled_Principal_n = [0 for _ in range(0,IIR_Calculation.shape[0])] # list(np.zeros(IIR_Calculation.shape[0]+1))


for n in Months_n:
    if n == 0:
        Scheduled_Principal_n[n] = 0 #round(npf.ppmt((CouponRate/12),Months_n[n],Term,-Invested),2)
    else:
        Scheduled_Principal_n[n] = round(npf.ppmt((CouponRate/12),Months_n[n],Term,-Invested),2)


## Calculate Scheduled_Interest
Scheduled_Interest_n = [0 for _ in range(0,IIR_Calculation.shape[0])] #list(np.zeros(IIR_Calculation.shape[0]))


for i in range(0,IIR_Calculation.shape[0]):
    if i == 0:
        Scheduled_Interest_n[i] = 0
    else:
        Scheduled_Interest_n[i] = float(npf.ipmt((CouponRate/12),i,Term,-Invested))



# Calculating Scheduled_Balance

Scheduled_Balance_n = [0 for _ in range(0,IIR_Calculation.shape[0])]#list(np.zeros(IIR_Calculation.shape[0]))
Scheduled_Balance_n[0] = Invested



for n in range(1, IIR_Calculation.shape[0]):
    if n == 0 :
        Scheduled_Balance_n[n] = Invested
    else:
        Scheduled_Balance_n[n] = Scheduled_Balance_n[n-1] - Scheduled_Principal_n[n]



# Calculating Prepay_Speed


Prepay_Speed_n =  [0 for _ in range(0,IIR_Calculation.shape[0])]#list(np.zeros(IIR_Calculation.shape[0])) #list(np.zeros(IIR_Calculation.shape[0]))

for n in range(0,len(Months_n)):
    if n == 0:
        Prepay_Speed_n[n] = 0
    else:
        Prepay_Speed_n[n] = Prepay.loc[n,Term]*100



# Calculating default rate

Default_Rate_n = [0 for _ in range(0,IIR_Calculation.shape[0])] #list(np.zeros(IIR_Calculation.shape[0]))


for n in range(0,len(Months_n)):
    Default_Rate_n[n] = Charged_off.loc[n+1,'36-C4']*100



# Calculating Recovery,Balance,Principal,Prepay_n and Default 

# For recovery
Recovery_n = [0 for _ in range(0,IIR_Calculation.shape[0])]

# For default
Default_n = [0 for _ in range(0,IIR_Calculation.shape[0])] #list(np.zeros(IIR_Calculation.shape[0]))

# For Balance
Balance_n = [0 for _ in range(0,IIR_Calculation.shape[0])] #list(np.zeros(IIR_Calculation.shape[0]+1))

# For principal
Principal_n = [0 for _ in range(0,IIR_Calculation.shape[0])] #list(np.zeros(IIR_Calculation.shape[0]+1,dtype='float64))
                            

# For Prepay_n
Prepay_n = [0 for _ in range(0,IIR_Calculation.shape[0])] # [0 for _ in range(0,IIR_Calculation.shape[0])] #


for n in range(0,len(Months_n)):
    if n == 0:
        Default_n[n] = 0
        Prepay_n[n] = 0
        Principal_n[n] = 0
        Balance_n[n]=Invested
        Recovery_n[n] = 0
  
    else:       
        Default_n[n] = Balance_n[n-1] * Default_Rate_n[n-1] * Default_Multiplier*0.01
        

        Prepay_n[n] = (Balance_n[n-1]-(((Balance_n[n-1] - Scheduled_Interest_n[n]) / Scheduled_Balance_n[n-1] ) * \
                                       Scheduled_Principal_n[n])) * Prepay_Speed_n[n]*0.01 * Prepay_Multiplier 
        
        Principal_n[n] = (((Balance_n[n-1] - Default_n[n]) / Scheduled_Balance_n[n-1]) * \
                          Scheduled_Principal_n[n]) + Prepay_n[n]


        Balance_n[n] = Balance_n[n-1] - Default_n[n] - Principal_n[n]

        
        Recovery_n[n] = Default_n[n] * Recovery_Rate



Servicing_CF_n = [0 for _ in range(0,IIR_Calculation.shape[0])]

for n in range(1,IIR_Calculation.shape[0]):
    Servicing_CF_n[n] = ((Balance_n[n-1] - Default_n[n]) * Servicing_Fee) / 12



# Calculating Earnout_CF

Earnout_Fee = 0.0250

Earnout_CF_n = [0 for _ in range(0,IIR_Calculation.shape[0])]

for n in range(0,IIR_Calculation.shape[0]):
    if n == 1:
        Earnout_CF_n[n] = 0
    elif n == 13 or  n == 19:
        Earnout_CF_n[n] = (Earnout_Fee / 2) * Invested
    else:
        Earnout_CF_n[n] = 0



# Calculate Interest_Amount

Interest_Amount_n = [0 for _ in range(0,IIR_Calculation.shape[0])]


for n in range(0,IIR_Calculation.shape[0]):
    if n == 0:
        Interest_Amount_n[n] =  0
    else:
        Interest_Amount_n[n] = ((Balance_n[n-1] - Default_n[n]) * CouponRate) / 12




# Calculate Total_CF
Total_CF_n = [0 for _ in range(0,IIR_Calculation.shape[0])]


for n in range(0,IIR_Calculation.shape[0]):
    if n == 0:
        Total_CF_n[n] = -Invested * (1 + Purchase_Premium)
    else:
        #print((Recovery_n[n] , Servicing_CF_n[n] , Earnout_CF_n[n]) , Principal_n[n],Interest_Amount_n[n])
        Total_CF_n[n] = (Recovery_n[n] + Servicing_CF_n[n] + Earnout_CF_n[n]) - Principal_n[n] - Interest_Amount_n[n]



output_dict = dict()
columns = ['Months',
       'Paymnt_Count', 'Paydate', 'Scheduled_Principal', 'Scheduled_Interest',
       'Scheduled_Balance', 'Prepay_Speed', 'Default_Rate', 'Recovery',
       'Servicing_CF', 'Earnout_CF', 'Balance', 'Principal', 'Default',
       'Prepay', 'Interest_Amount', 'Total_CF']
for i in columns:
    output_dict[i]=list(eval(i+str('_n')))




df = pd.DataFrame(output_dict)


print(df)




# The polynomial made from  last column Total_CF and each cell is a single term of the polynomial

def f(x): return [ele*x**i for i,ele in enumerate(Total_CF_n)] # function
def df(y): return [(i+1)*ele*y**(i) for i,ele in enumerate(Total_CF_n[1:])] # first derivative of the function

# Initial Parameters a gussed value and tolerated error
x_0 = 1
tolerance = 1.0e-9

while True:
    f_x_0 = sum(f(x_0)) # Evaluating function at x_0
    df_x_0 = sum(df(x_0)) # Evaluating function's derivative at x_0 
    
    x_1 = x_0 - (f_x_0/df_x_0) # Newton's Raphson formula
    print('\n')
    if (abs(x_1) - abs(x_0))  < tolerance:
        print(f"appriximated root is = {x_0,x_1}")
        break
    else:
        x_0 = x_1


